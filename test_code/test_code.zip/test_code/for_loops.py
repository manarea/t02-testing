x = ["a", "b", "c"]
for i in x:
    print(i)
for i in range(0, 10):
    print(i)
    
# More for loops

for i in range(10):
    print(i)
for i in range(0, 10):
    print(i)
for i in range(0, 10, 1):
    print(i)
for i in range(0, 10, 2):
    print(i)
for i in range(10, 0, -1):