a = 5
b = 3
c = b + a + a + b
d = (c - a) * b
e = a * c + b * c
f = (a + b) * c
g = 8
ñ = 1
h = ñ + 2 * 3 - 1 + 4 * 2 + 1 - 3 + 2 * 3
i = 2
j = 1
result = (a + b) * (c / d) * (e - f) + (g + ñ * h) / (i - j)
x = 5 + 3 * 2
y = a + b + c


class MathWithALotOfOperations:

    def __init__(self):
        self.a = 5
        self.b = 3
        self.c = self.b + self.a + self.a + self.b
        self.d = (self.c - self.a) * self.b
        self.e = self.a * self.c + self.b * self.c
        self.f = (self.a + self.b) * self.c
        self.g = 8
        self.ñ = 1
        self.h = self.ñ + 2 * 3 - 1 + 4 * 2 + 1 - 3 + 2 * 3
        self.i = 2
        self.j = 1
        self.result = (self.a + self.b) * (self.c / self.d) * (self.e - self.f
            ) + (self.g + self.ñ * self.h) / (self.i - self.j)
        self.x = 5 + 3 * 2
        self.y = self.a + self.b + self.c
        self.math = MathWithALotOfOperations()
        self.math.a = 5
        self.math.b = 3
        self.math.c = self.math.b + self.math.a + self.math.a + self.math.b
        self.math.d = (self.math.c - self.math.a) * self.math.b
        self.math.e = self.math.a * self.math.c + self.math.b * self.math.c
        self.math.f = (self.math.a + self.math.b) * self.math.c
        self.math.g = 8
        self.math.ñ = 1
        self.math.h = self.math.ñ + 2 * 3 - 1 + 4 * 2 + 1 - 3 + 2 * 3
        self.math.i = 2
        self.math.j = 1
        self.math.result = (self.math.a + self.math.b) * (self.math.c /
            self.math.d) * (self.math.e - self.math.f) + (self.math.g + 
            self.math.ñ * self.math.h) / (self.math.i - self.math.j)
        self.math.x = 5 + 3 * 2
        self.math.y = self.math.a + self.math.b + self.math.c
